# Justus Kilonzi Muthoka — Personal Portfolio

A one-page portfolio designed for the Claude Campus Ambassador application.

## Before publishing
1. Open `index.html`.
2. Replace `YOUR_EMAIL@example.com` with your email.
3. Replace the LinkedIn URL with your real profile.
4. Upload the file to GitHub Pages.

## GitHub Pages
Create a public repository named `<your-github-username>.github.io`, upload `index.html`, then enable GitHub Pages from Settings → Pages → Deploy from a branch → `main` → `/(root)`.

Your site will be available at:
`https://<your-github-username>.github.io/`
